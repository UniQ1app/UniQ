# 1. Executive Summary
UNIQ is a merit-based application-layer ecosystem built on Qubic.
...
(Detailed content here)