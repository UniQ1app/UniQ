# 3.1 The Academy (Education Hub)
Entry point hub for all users.
...(Detailed content here)