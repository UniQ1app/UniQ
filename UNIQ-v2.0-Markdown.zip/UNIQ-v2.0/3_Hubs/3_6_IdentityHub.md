# 3.6 Identity Hub (Meritocratic CV)
Tracks Merit Score, wallet, and role.
...(Detailed content here)